﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace UEFA.Models
{
    public class MatchDetails
    {
        public Team HomeTeam { get; set; }
        public int HomeTeamId { get; set; }

        public Team AwayTeam { get; set; }
        public int AwayTeamId { get; set; }

        public int HomeTeamGoals { get; set; } 
        public int AwayTeamGoals { get; set; }

        public MatchStats YellowCardsHomeTeam { get; set; }

        public MatchStats RedCardsHomeTeam { get; set; }

        public MatchStats AwayTeamStats { get; set; }

        public MatchStats HomeTeamStats { get; set; }
    }
}