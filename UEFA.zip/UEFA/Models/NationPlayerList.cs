﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace UEFA.Models
{
    public class NationPlayerList
    {
      public Nation Nation { get; set; }  //table
    
      public List<Players> Players { get; set; } //table

    }

}