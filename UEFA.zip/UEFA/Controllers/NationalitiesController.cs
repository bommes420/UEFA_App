﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using UEFA;
using UEFA.Models;

namespace UEFA.Controllers
{
    public class NationalitiesController : Controller
    {
        private UEFA_DBEntities db = new UEFA_DBEntities();
        // GET: Nationalities
        public ActionResult Index()
        {
            return View(db.Nation.ToList());
        }

        public ActionResult Details(int id)
        {
            //make new instance of class, proceed to connect queries to the instances and return a view
            NationPlayerList nationPlayerList = new NationPlayerList(); // new table instance
            nationPlayerList.Players = db.Players.Where(p => p.Nation_ID == id).ToList(); // connect nation_ID to page ID
            nationPlayerList.Nation = db.Nation.Single(n => n.Nation_ID == id); // show single instance (by ID)

            return View(nationPlayerList); // show created instance
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
