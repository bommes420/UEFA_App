﻿using System;
using System.Diagnostics;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using UEFA;
using UEFA.Models;

namespace UEFA.Controllers
{
    public class MatchInfoController : Controller
    {
        private UEFA_DBEntities db = new UEFA_DBEntities();
        public ActionResult Index()
        {

            // create result variable to later on pass it to the view.
            List<MatchDetails> result = new List<MatchDetails>();

            foreach (MatchStats item in db.MatchStats)
            {
                // create new MatchDetails instance
                MatchDetails matchDetails = new MatchDetails(); 

                // make the hometeamID from this instance equal to the ID value from the database
                matchDetails.HomeTeamId = item.Home_Team_ID;

                // look for nation (country) that is equivalent to the hometeamID
                Nation HomeTeam = db.Nation.Single(n => n.Nation_ID == matchDetails.HomeTeamId);


                //make a new Team instance
                Team homeTeam = new Team();
                
                //make the team name of the hometeam equal to the name of the country
                homeTeam.TeamName = HomeTeam.Country;

                // get matchDetails property, get the HomeTeamFlag property and set it equal to the Flag property in the database
                homeTeam.TeamFlag = HomeTeam.Flag;
                
                //make home team property equal to the homeTeam variable
                matchDetails.HomeTeam = homeTeam;


                matchDetails.AwayTeamId = item.Away_Team_ID;

                Nation AwayTeam = db.Nation.Single(n => n.Nation_ID == matchDetails.AwayTeamId);

                Team awayTeam = new Team();
                
                awayTeam.TeamName = AwayTeam.Country;
                awayTeam.TeamFlag = AwayTeam.Flag;

                matchDetails.AwayTeam = awayTeam;
                
                matchDetails.HomeTeamGoals = item.GoalsHomeTeam;
                matchDetails.AwayTeamGoals = item.GoalsAwayTeam;

                //add the matchdetails item(s) to the result 
                result.Add(matchDetails);
            }

            // pass all results to the view.
            return View(result);
        }

        public ActionResult Details(int id)
        {

            //klasse opnieuw schrijven
            MatchDetails matchDetails = new MatchDetails();
            

            NationPlayerList nationPlayerList = new NationPlayerList(); // new table instance
            //nationPlayerList.Players = db.MatchStats.Where(match => match.Match_ID == id).ToList(); // connect nation_ID to page ID
            nationPlayerList.Nation = db.Nation.Single(n => n.Nation_ID == id); // show single instance (by ID)

            //return View(nationPlayerList); // show created instance
            return View();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
